import { GoogleGenAI } from "@google/genai";

const apiKey = process.env.API_KEY || '';
const ai = new GoogleGenAI({ apiKey });

export const generateLyrics = async (mood: string): Promise<string> => {
  if (!apiKey) {
    return "The connection to the muse is currently severed.";
  }

  try {
    const prompt = `
      You are an AI collaborator for NUTSAQ, a sophisticated, award-winning electronic music duo. 
      Generate a short piece of avant-garde poetry (4-6 lines) inspired by the concept: "${mood}".
      
      Tone: Intellectual, existential, elegant, abstract. 
      Reference style: Samuel Beckett meets T.S. Eliot in a digital age.
      Format: Clean text, no markdown, lower case only.
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
    });

    return response.text || "Silence is also an answer.";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "The machine is contemplating.";
  }
};
