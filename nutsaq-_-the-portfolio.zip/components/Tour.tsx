import React from 'react';
import { TOUR_DATES } from '../constants';

export const Tour: React.FC = () => {
  return (
    <section id="tour" className="py-32 bg-obsidian text-white">
      <div className="max-w-[1000px] mx-auto px-6 lg:px-12">
        <div className="text-center mb-24">
            <h2 className="font-serif text-4xl md:text-5xl italic mb-4">
                Engagements
            </h2>
            <p className="font-sans text-xs tracking-widest text-gray-500 uppercase">
                Live Performances
            </p>
        </div>

        <div className="w-full">
          {TOUR_DATES.map((show) => (
            <div 
              key={show.id}
              className="group flex flex-col md:flex-row md:items-baseline justify-between py-8 border-b border-white/10 hover:border-white/30 transition-colors duration-500"
            >
              <div className="flex items-baseline gap-12 w-full md:w-1/2">
                <span className="font-sans text-xs tracking-widest text-gray-500 w-16">{show.date}</span>
                <span className="font-serif text-2xl text-gray-300 group-hover:text-white transition-colors">
                    {show.city}
                </span>
              </div>

              <div className="flex items-center justify-between md:justify-end w-full md:w-1/2 mt-4 md:mt-0 gap-8">
                <span className="font-serif italic text-gray-500 text-lg">
                    {show.venue}
                </span>
                
                <div className="w-24 text-right">
                    {show.status === 'Sold Out' ? (
                        <span className="inline-block w-2 h-2 rounded-full bg-gray-700"></span>
                    ) : show.status === 'Few Left' ? (
                        <span className="inline-block w-2 h-2 rounded-full bg-white animate-pulse"></span>
                    ) : (
                        <span className="font-sans text-[10px] tracking-widest uppercase border border-white/20 px-4 py-2 hover:bg-white hover:text-black transition-colors cursor-pointer">
                            RSVP
                        </span>
                    )}
                </div>
              </div>
            </div>
          ))}
        </div>
        
        <div className="mt-12 text-center">
             <p className="font-serif italic text-gray-600 text-sm">
                 * For private commissions, please contact management.
             </p>
        </div>
      </div>
    </section>
  );
};
