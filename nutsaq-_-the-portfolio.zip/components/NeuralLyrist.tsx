import React, { useState } from 'react';
import { generateLyrics } from '../services/geminiService';

export const NeuralLyrist: React.FC = () => {
  const [mood, setMood] = useState('');
  const [lyrics, setLyrics] = useState('');
  const [loading, setLoading] = useState(false);

  const handleGenerate = async () => {
    if (!mood.trim()) return;
    setLoading(true);
    setLyrics('');
    try {
      const result = await generateLyrics(mood);
      setLyrics(result);
    } catch (e) {
      setLyrics("Silence.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <section id="ai" className="py-32 bg-paper text-obsidian flex justify-center">
      <div className="max-w-2xl w-full px-6 text-center">
        
        <h2 className="font-serif text-3xl italic mb-2">The Machine Muse</h2>
        <p className="font-sans text-[10px] tracking-widest uppercase text-gray-500 mb-16">
            Gemini 3 Flash Preview
        </p>

        {/* Input */}
        <div className="relative mb-20 group">
             <input
                type="text"
                value={mood}
                onChange={(e) => setMood(e.target.value)}
                placeholder="Enter a concept for the machine..."
                className="w-full bg-transparent border-b border-gray-300 py-4 font-serif text-xl text-center focus:outline-none focus:border-obsidian transition-colors placeholder:text-gray-400 italic"
                onKeyDown={(e) => e.key === 'Enter' && handleGenerate()}
              />
              <button 
                onClick={handleGenerate}
                disabled={loading || !mood}
                className="mt-8 font-sans text-[10px] tracking-widest uppercase text-gray-400 hover:text-obsidian disabled:opacity-0 transition-all duration-500"
              >
                {loading ? 'Contemplating...' : 'Invoke'}
              </button>
        </div>

        {/* Output */}
        <div className="min-h-[200px] flex items-center justify-center">
            {lyrics && (
                <div className="font-serif text-2xl leading-loose italic animate-fade-in text-gray-800">
                    {lyrics.split('\n').map((line, i) => (
                        <p key={i}>{line}</p>
                    ))}
                </div>
            )}
        </div>

      </div>
    </section>
  );
};
