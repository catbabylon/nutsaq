import React from 'react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-obsidian text-gray-600 py-24 border-t border-white/5">
      <div className="max-w-[1400px] mx-auto px-6 lg:px-12 flex flex-col md:flex-row justify-between items-center md:items-end">
        
        <div className="text-center md:text-left mb-12 md:mb-0">
          <h2 className="font-serif text-2xl text-white mb-2 tracking-widest">NUTSAQ</h2>
          <p className="font-sans text-[10px] tracking-widest uppercase">
            London — Berlin — Tokyo
          </p>
        </div>

        <div className="flex flex-col items-center md:items-end space-y-4">
             <div className="flex space-x-8 font-sans text-[10px] tracking-widest uppercase">
                <a href="#" className="hover:text-white transition-colors">Instagram</a>
                <a href="#" className="hover:text-white transition-colors">Twitter</a>
                <a href="#" className="hover:text-white transition-colors">Spotify</a>
             </div>
             <p className="font-sans text-[10px] tracking-widest uppercase opacity-50">
                © 2024 NUTSAQ Audio Research. All Rights Reserved.
             </p>
        </div>
      </div>
    </footer>
  );
};
