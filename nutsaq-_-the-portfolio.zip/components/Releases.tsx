import React from 'react';
import { RELEASES } from '../constants';

export const Releases: React.FC = () => {
  return (
    <section id="works" className="py-32 bg-charcoal text-white">
      <div className="max-w-[1400px] mx-auto px-6 lg:px-12">
        <div className="flex flex-col md:flex-row justify-between items-end mb-24 border-b border-white/10 pb-8">
            <h2 className="font-serif text-4xl md:text-5xl italic">
            Selected Works
            </h2>
            <span className="font-sans text-xs tracking-widest text-gray-500 mt-4 md:mt-0 uppercase">
                Discography 2022 — 2024
            </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-x-8 gap-y-16">
          {RELEASES.map((release) => (
            <div key={release.id} className="group cursor-pointer">
              <div className="aspect-square overflow-hidden bg-black mb-6 relative">
                 <img 
                   src={release.coverUrl} 
                   alt={release.title}
                   className="w-full h-full object-cover grayscale opacity-70 group-hover:opacity-100 transition-opacity duration-700 ease-out"
                 />
                 <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-500">
                    <span className="font-serif italic text-2xl text-white">Listen</span>
                 </div>
              </div>
              
              <div className="flex flex-col space-y-1">
                <span className="font-sans text-[10px] tracking-widest text-gray-500 uppercase">
                    {release.year} — {release.type}
                </span>
                <h3 className="font-serif text-2xl text-gray-200 group-hover:text-white transition-colors">
                    {release.title}
                </h3>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
