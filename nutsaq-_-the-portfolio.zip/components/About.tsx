import React from 'react';

export const About: React.FC = () => {
  return (
    <section id="biography" className="py-32 md:py-48 bg-obsidian text-paper">
        <div className="max-w-[1400px] mx-auto px-6 lg:px-12">
            <div className="flex flex-col lg:flex-row gap-20 items-center">
                
                {/* Image Section */}
                <div className="w-full lg:w-5/12 order-2 lg:order-1">
                    <div className="relative overflow-hidden">
                         <img 
                            src="https://images.unsplash.com/photo-1506157786151-b8491531f063?q=80&w=1200&auto=format&fit=crop&grayscale" 
                            alt="The Duo" 
                            className="w-full h-[600px] object-cover grayscale opacity-80 hover:scale-105 transition-transform duration-[2s]"
                         />
                         <div className="absolute bottom-4 right-4 font-sans text-[10px] tracking-widest text-white/50">
                            FIG 1. THE ARCHITECTS
                         </div>
                    </div>
                </div>
                
                {/* Text Content */}
                <div className="w-full lg:w-7/12 order-1 lg:order-2 lg:pl-12">
                    <h2 className="font-serif text-4xl md:text-5xl mb-12 italic text-gray-200">
                        A Study in Sound
                    </h2>
                    
                    <div className="font-serif font-light text-xl md:text-2xl leading-relaxed text-gray-400 space-y-8 editorial-text">
                        <p>
                            In an era of noise, <span className="text-white">NUTSAQ</span> offers silence, punctuated by precise, calculated rhythm.
                        </p>
                        <p>
                            Recipients of the prestigious <span className="text-white italic">Ivor Novello Award</span>, the duo operates at the intersection of classical composition and brutalist electronics. Their work is not merely heard but inhabited—structures of sound built to house the complexities of the modern condition.
                        </p>
                    </div>

                    <div className="mt-16 pt-8 border-t border-white/10 flex justify-between items-center">
                        <span className="font-sans text-xs tracking-widest uppercase text-gray-500">Press Quote</span>
                        <p className="font-serif italic text-gray-300 max-w-md text-right">
                            "Elegant devastation. They have elevated the synthesizer to the status of a grand piano." 
                            <span className="block not-italic font-sans text-[10px] mt-2 text-gray-600 uppercase">— The Guardian Arts</span>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>
  );
};
