import React from 'react';

export const Hero: React.FC = () => {
  return (
    <section className="relative h-screen w-full flex flex-col justify-center items-center overflow-hidden bg-obsidian">
      
      {/* Background Image - Subtle Parallax Feel */}
      <div className="absolute inset-0 z-0">
        <img 
          src="https://images.unsplash.com/photo-1514525253440-b393452e8d26?q=80&w=2800&auto=format&fit=crop&grayscale"
          alt="Abstract Architecture"
          className="w-full h-full object-cover opacity-30"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-obsidian/40 via-transparent to-obsidian" />
      </div>

      <div className="z-10 text-center px-4 max-w-4xl mx-auto animate-fade-in">
        <span className="block font-sans text-[10px] md:text-xs tracking-art text-gray-400 mb-8 uppercase">
          Est. 2012 — London
        </span>
        
        <h1 className="font-serif text-6xl md:text-9xl text-paper mb-6 tracking-tight leading-none italic">
          NUTSAQ
        </h1>

        <div className="h-px w-24 bg-white/20 mx-auto my-8"></div>

        <p className="font-sans font-light text-gray-400 text-sm md:text-base tracking-widest uppercase max-w-lg mx-auto">
          Electronic Composition & <br/> Auditory Architecture
        </p>
      </div>

      <div className="absolute bottom-12 left-0 right-0 text-center animate-slide-up">
        <span className="font-serif text-xs italic text-gray-600">Scroll to Explore</span>
      </div>
    </section>
  );
};
